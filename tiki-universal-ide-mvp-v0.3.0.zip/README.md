# TIKI Universal IDE — MVP 0.3.0

Local-first, plugin-ready AI coding workspace. This starter is intentionally dependency-free: it uses Node.js built-ins and static HTML/CSS/JS, so the UI itself does not need a package install.

## What works in this MVP

- Local web UI with responsive layout.
- Runtime and executable detection.
- OpenCode native API connector.
- Hermes and OpenClaw OpenAI-compatible API connectors.
- SSE event timeline for observed status and streamed text.
- **TIKI-owned core system prompt** applied by the TIKI server before requests reach provider adapters.
- Local custom-instructions editor; custom rules are stored in TIKI config, not the project workspace.
- Prompt version fingerprint emitted with each run for traceability.
- Workspace file listing, file preview, and saving existing files.
- A small command allowlist with an explicit confirmation dialog.
- Sub-agent manager with add, enable/disable, remove, and local `.tiki/subagents.json` persistence.
- MCP adapter boundary and SDK adapter contract for future trusted plugins.
- Separate `tools/` area for non-AI public API integrations (weather, markets, datasets, compliant scraping); catalog is currently an extension-point demo.
- Workspace path guard, symlink boundary check, request body limits, and loopback-only default bind.
- Bash and PowerShell launchers.

## Requirements

- Node.js 20 or newer.
- An agent server running separately for real agent calls.
- No npm packages required.

## Run

From the repository:

```sh
./install.sh
./launchers/tiki-ide
```

Or directly:

```sh
TIKI_WORKSPACE="$PWD" node server.mjs
```

Open the URL printed by the launcher, default `http://127.0.0.1:4317`.

On Windows PowerShell:

```powershell
$env:TIKI_WORKSPACE = (Get-Location).Path
.\launchers\tiki-ide.ps1
```

## Connect agents

Copy `.env.example` values into your shell environment or a local `.env` loader of your choice. The server intentionally does not parse `.env` files automatically and does not ship a dotenv dependency.

### OpenCode

Start the OpenCode server separately, bound to loopback, for example:

```sh
opencode serve --hostname 127.0.0.1 --port 4096
```

Set `OPENCODE_URL=http://127.0.0.1:4096` if you use a different endpoint. The MVP uses the native session/message HTTP API. Native tool-event forwarding and per-message diff integration are follow-up work; this MVP does not pretend that the final response is a live tool log.

### Hermes

Enable its API server in Hermes configuration and set a strong `API_SERVER_KEY`; start its gateway. Configure:

```sh
HERMES_URL=http://127.0.0.1:8642/v1
HERMES_API_KEY=your-local-secret
```

Hermes has a documented OpenAI-compatible API. Tool-progress events vary by server version/configuration.

### OpenClaw

Configure its OpenAI-compatible HTTP endpoint and gateway token:

```sh
OPENCLAW_URL=http://127.0.0.1:18789/v1
OPENCLAW_API_KEY=your-local-secret
```

Check the endpoint and auth settings against your installed OpenClaw version. Detection uses `GET /models`.

## Security boundaries in this MVP

- Default host is `127.0.0.1`. Keep it that way for local use.
- Do not expose this service to a LAN, tunnel, or public internet as-is. It has no user authentication, TLS, CSRF protection, or multi-user isolation.
- Agent connectors may execute powerful tools under their own permissions. Keep their gateways private and use their own auth.
- Workspace file routes are confined to the configured workspace and reject symlink escapes.
- Only the four named commands in the UI are accepted; arbitrary shell commands are not accepted.
- The command runner does not use a shell and has a 10-second timeout.
- The editor saves only existing files and limits files to 500 KB.

## TIKI prompt ownership and provider adapters

TIKI owns the product-level prompt in `core/system-prompt.md`. OpenCode, Hermes, and OpenClaw are execution providers; they do not define TIKI's product identity or task framing. For OpenAI-compatible providers, the server sends the effective TIKI instructions as a `system` message. The OpenCode adapter passes the same instructions using the native message request's `system` field. Actual precedence still depends on each runtime's own API semantics and may include provider/runtime policies that TIKI cannot replace.

The optional custom instructions are saved to the TIKI config directory (`~/.config/tiki-ide/system-prompt.override.md` on Unix-like systems; `%APPDATA%\TIKI\IDE\system-prompt.override.md` on Windows, unless `TIKI_CONFIG_DIR` is set). They are appended to the TIKI core prompt. The UI shows the core prompt and lets the user edit only the optional custom instructions. Do not put secrets in prompt text.

The effective prompt has a SHA-256-derived version fingerprint. Runs emit `prompt.attached`, and changes emit `prompt.updated`. This is for traceability; it is not cryptographic proof that a provider obeyed the prompt.

## Current prompt integration limits

- This is the first central prompt layer, not a full policy engine. Filesystem permissions, tool approval, command restrictions, and network controls must still be enforced server-side.
- OpenCode's native API behavior may vary by version; verify that its `system` field is honored by the exact installed version. If it is ignored, the adapter must be updated to use a supported agent/config mechanism or a clearly documented fallback.
- The selected provider may have its own system/developer instructions that TIKI cannot remove. TIKI owns the prompt it sends, but cannot guarantee absolute precedence over a remote runtime's internal policy.

## MCP, SDKs, sub-agents, and non-AI tools

- `plugins/mcp-adapter.mjs` documents the MCP integration boundary; it is not yet a full MCP transport client. Wire a maintained MCP SDK before connecting arbitrary MCP servers.
- `plugins/sdk-adapter.mjs` defines a trusted local SDK plugin contract. SDK packages are not downloaded or executed from the browser.
- Sub-agent definitions can be added, enabled/disabled, and removed. This MVP persists the definitions but does not yet orchestrate parallel sub-agent runs.
- `tools/` is separate from AI agent APIs. The current catalog describes weather, market data, public APIs, and web extraction as extension points; it does not claim to fetch live provider data yet.
- Web extraction connectors must use explicit domain allowlists, request timeouts, response-size limits, rate limits, and respect site terms/robots policies. Do not implement arbitrary URL fetching from user input.

## Known MVP limitations

- No arbitrary command terminal, no remote control plane, no multi-user auth.
- File explorer displays a flattened tree; nested-folder navigation is limited.
- No automatic file diff generation yet; the UI reports file saves and streamed agent text.
- OpenCode response is currently returned after the native request completes; true live OpenCode tool event/diff forwarding is a planned adapter enhancement.
- Agent health detection is best-effort and may show offline if auth/configuration differs.
- Cross-platform portability depends on Node.js and each agent's own platform support.

## Roadmap

1. Complete MCP transport with a maintained MCP SDK and explicit server trust/approval.
2. Adapter registry and capability negotiation.
3. OpenCode global-event SSE relay + native diff rendering.
4. Hermes/OpenClaw named tool-event parsing with version-aware adapters.
5. Safe command approval queue with explicit, narrow capabilities.
6. Full nested file explorer, Monaco/CodeMirror editor, Git diff review.
7. Real weather/market/public API providers and compliant scraping connectors.
8. Sub-agent orchestration and lifecycle controls.
9. Portable packaged builds and authenticated remote bridge.

## Checks

```sh
npm run check
node server.mjs
```
