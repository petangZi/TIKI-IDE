import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import { spawn, spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { createSubagentStore } from "./plugins/subagents.mjs";
import { createPromptManager } from "./core/prompt-manager.mjs";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC = path.join(HERE, "public");
const HOST = process.env.TIKI_HOST || "127.0.0.1";
const PORT = Number(process.env.TIKI_PORT || 4317);
const WORKSPACE_INPUT = process.env.TIKI_WORKSPACE || process.argv.find((x) => x.startsWith("--workspace="))?.split("=").slice(1).join("=") || process.cwd();
const WORKSPACE = fs.realpathSync(path.resolve(WORKSPACE_INPUT));
const MAX_BODY = 1_000_000;
const clients = new Set();
const sessions = new Map();
const subagents = createSubagentStore(WORKSPACE);
const DEFAULT_CONFIG_DIR = process.env.APPDATA && process.platform === "win32"
  ? path.join(process.env.APPDATA, "TIKI", "IDE")
  : path.join(os.homedir(), ".config", "tiki-ide");
const promptManager = createPromptManager(process.env.TIKI_CONFIG_DIR || DEFAULT_CONFIG_DIR);

function json(res, status, value) {
  res.writeHead(status, { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" });
  res.end(JSON.stringify(value));
}
function event(event) {
  const payload = `data: ${JSON.stringify({ ...event, at: new Date().toISOString() })}\n\n`;
  for (const client of clients) client.write(payload);
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", (chunk) => {
      body += chunk;
      if (body.length > MAX_BODY) { reject(new Error("Request body too large")); req.destroy(); }
    });
    req.on("end", () => {
      try { resolve(body ? JSON.parse(body) : {}); } catch { reject(new Error("Invalid JSON")); }
    });
    req.on("error", reject);
  });
}
function commandExists(name) {
  const isWindows = process.platform === "win32";
  const r = isWindows
    ? spawnSync("where", [name], { encoding: "utf8", timeout: 1500, windowsHide: true })
    : spawnSync("sh", ["-lc", `command -v ${name}`], { encoding: "utf8", timeout: 1500 });
  return r.status === 0 ? r.stdout.trim().split(/\r?\n/)[0] : null;
}
function safePath(input = ".") {
  const candidate = path.resolve(WORKSPACE, String(input));
  if (candidate !== WORKSPACE && !candidate.startsWith(WORKSPACE + path.sep)) throw new Error("Path escapes the selected workspace");
  let existing = candidate;
  while (!fs.existsSync(existing)) {
    const parent = path.dirname(existing);
    if (parent === existing) break;
    existing = parent;
  }
  const realExisting = fs.realpathSync(existing);
  if (realExisting !== WORKSPACE && !realExisting.startsWith(WORKSPACE + path.sep)) throw new Error("Symlink escapes the selected workspace");
  return candidate;
}
function relativeName(abs) {
  return path.relative(WORKSPACE, abs).split(path.sep).join("/") || ".";
}
function listTree(dir, depth = 0, out = []) {
  if (depth > 4 || out.length > 500) return out;
  let entries = [];
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return out; }
  entries.sort((a,b) => Number(b.isDirectory()) - Number(a.isDirectory()) || a.name.localeCompare(b.name));
  for (const e of entries) {
    if ([".git", "node_modules", ".next", "dist", "build", ".venv", "__pycache__"].includes(e.name)) continue;
    const abs = path.join(dir, e.name);
    let stat;
    try { stat = fs.lstatSync(abs); } catch { continue; }
    if (stat.isSymbolicLink()) continue;
    const item = { name: e.name, path: relativeName(abs), type: e.isDirectory() ? "dir" : "file" };
    out.push(item);
    if (e.isDirectory()) listTree(abs, depth + 1, out);
    if (out.length > 500) break;
  }
  return out;
}
async function fetchJson(url, options = {}, timeoutMs = 1200) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, { ...options, signal: controller.signal });
    const text = await response.text();
    let data;
    try { data = text ? JSON.parse(text) : null; } catch { data = text; }
    return { ok: response.ok, status: response.status, data };
  } catch (error) {
    return { ok: false, error: error.message };
  } finally { clearTimeout(timer); }
}
async function discoverAgents() {
  const ocUrl = (process.env.OPENCODE_URL || "http://127.0.0.1:4096").replace(/\/$/, "");
  const hermesUrl = (process.env.HERMES_URL || "http://127.0.0.1:8642/v1").replace(/\/$/, "");
  const clawUrl = (process.env.OPENCLAW_URL || "http://127.0.0.1:18789/v1").replace(/\/$/, "");
  const [oc, hermes, claw] = await Promise.all([
    fetchJson(`${ocUrl}/global/health`),
    fetchJson(`${hermesUrl}/models`, { headers: process.env.HERMES_API_KEY ? { authorization: `Bearer ${process.env.HERMES_API_KEY}` } : {} }),
    fetchJson(`${clawUrl}/models`, { headers: process.env.OPENCLAW_API_KEY ? { authorization: `Bearer ${process.env.OPENCLAW_API_KEY}` } : {} })
  ]);
  return [
    { id: "opencode", name: "OpenCode", kind: "native-api", detected: !!oc.ok, detail: oc.ok ? `API online${oc.data?.version ? ` · ${oc.data.version}` : ""}` : "API not reachable", url: ocUrl },
    { id: "hermes", name: "Hermes", kind: "openai-compatible", detected: !!hermes.ok, detail: hermes.ok ? "API online" : "API not reachable / key not configured", url: hermesUrl },
    { id: "openclaw", name: "OpenClaw", kind: "openai-compatible", detected: !!claw.ok, detail: claw.ok ? "API online" : "API not reachable / key not configured", url: clawUrl }
  ];
}
async function sendOpenAICompatible(agentId, prompt, sessionId, systemPrompt) {
  const isHermes = agentId === "hermes";
  const base = (isHermes ? process.env.HERMES_URL || "http://127.0.0.1:8642/v1" : process.env.OPENCLAW_URL || "http://127.0.0.1:18789/v1").replace(/\/$/, "");
  const key = isHermes ? process.env.HERMES_API_KEY : process.env.OPENCLAW_API_KEY;
  const headers = { "content-type": "application/json" };
  if (key) headers.authorization = `Bearer ${key}`;
  event({ type: "agent.status", agent: agentId, text: `Sending request to ${isHermes ? "Hermes" : "OpenClaw"}…` });
  const response = await fetch(`${base}/chat/completions`, {
    method: "POST", headers,
    body: JSON.stringify({ model: isHermes ? "hermes-agent" : "openclaw/default", stream: true, messages: [{ role: "system", content: systemPrompt }, { role: "user", content: prompt }] })
  });
  if (!response.ok) throw new Error(`${agentId} API returned HTTP ${response.status}: ${(await response.text()).slice(0, 300)}`);
  if (!response.body) throw new Error("Agent response did not include a stream");
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "", answer = "";
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() || "";
    for (const line of lines) {
      if (line.startsWith("event:")) {
        const eventName = line.slice(6).trim();
        if (eventName.includes("tool.progress")) event({ type: "tool.progress", agent: agentId, text: "Agent reported tool activity" });
      } else if (line.startsWith("data:")) {
        const raw = line.slice(5).trim();
        if (!raw || raw === "[DONE]") continue;
        try {
          const data = JSON.parse(raw);
          const delta = data.choices?.[0]?.delta?.content;
          if (typeof delta === "string" && delta) { answer += delta; event({ type: "assistant.delta", sessionId, text: delta }); }
          const toolCalls = data.choices?.[0]?.delta?.tool_calls;
          if (toolCalls?.length) event({ type: "tool.progress", agent: agentId, text: "Agent is invoking a tool" });
        } catch {}
      }
    }
  }
  return answer || "(Agent completed without a text response.)";
}
async function sendOpenCode(prompt, sessionId, systemPrompt) {
  const base = (process.env.OPENCODE_URL || "http://127.0.0.1:4096").replace(/\/$/, "");
  const headers = { "content-type": "application/json" };
  event({ type: "agent.status", agent: "opencode", text: "Creating OpenCode session…" });
  let response = await fetch(`${base}/session`, { method: "POST", headers, body: JSON.stringify({ title: prompt.slice(0, 64) || "TIKI Workspace" }) });
  if (!response.ok) throw new Error(`OpenCode session API returned HTTP ${response.status}`);
  const session = await response.json();
  const id = session.id;
  if (!id) throw new Error("OpenCode did not return a session id");
  sessions.set(sessionId, { agent: "opencode", nativeSessionId: id });
  event({ type: "agent.status", agent: "opencode", text: "Prompt sent; waiting for OpenCode response…" });
  response = await fetch(`${base}/session/${encodeURIComponent(id)}/message`, {
    method: "POST", headers, body: JSON.stringify({ system: systemPrompt, parts: [{ type: "text", text: prompt }] })
  });
  if (!response.ok) throw new Error(`OpenCode prompt API returned HTTP ${response.status}: ${(await response.text()).slice(0, 300)}`);
  const data = await response.json();
  const answer = (data.parts || []).filter(p => p.type === "text").map(p => p.text || "").join("\n");
  if (answer) event({ type: "assistant.delta", sessionId, text: answer });
  return answer || "(OpenCode completed without a text response.)";
}
async function runChat(agentId, prompt) {
  const sessionId = crypto.randomUUID();
  const promptConfig = promptManager.get();
  event({ type: "prompt.attached", sessionId, agent: agentId, promptVersion: promptConfig.version, text: `TIKI core prompt attached to provider request · ${promptConfig.version}` });
  event({ type: "run.started", sessionId, agent: agentId, text: `Started ${agentId} run` });
  try {
    const answer = agentId === "opencode" ? await sendOpenCode(prompt, sessionId, promptConfig.effectivePrompt) :
      (agentId === "hermes" || agentId === "openclaw") ? await sendOpenAICompatible(agentId, prompt, sessionId, promptConfig.effectivePrompt) :
      (() => { throw new Error("Unknown agent"); })();
    event({ type: "run.completed", sessionId, agent: agentId, success: true, text: "Run completed" });
    return { sessionId, answer };
  } catch (error) {
    event({ type: "run.error", sessionId, agent: agentId, text: error.message });
    throw error;
  }
}
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || "127.0.0.1"}`);
  try {
    if (req.method === "GET" && url.pathname === "/api/health") {
      return json(res, 200, { ok: true, name: "TIKI Universal IDE", version: "0.3.0", workspace: WORKSPACE, node: process.version });
    }
    if (req.method === "GET" && url.pathname === "/api/runtime") {
      return json(res, 200, { platform: process.platform, arch: process.arch, node: process.version, hostname: os.hostname(), workspace: WORKSPACE,
        commands: Object.fromEntries(["git", "opencode", "hermes", "openclaw", "npm", "python3"].map(n => [n, !!commandExists(n)])), agents: await discoverAgents() });
    }
    if (req.method === "GET" && url.pathname === "/api/tree") {
      const abs = safePath(url.searchParams.get("path") || ".");
      if (!fs.existsSync(abs) || !fs.statSync(abs).isDirectory()) return json(res, 400, { error: "Folder not found" });
      return json(res, 200, { workspace: WORKSPACE, path: relativeName(abs), entries: listTree(abs).map(x => ({ ...x, path: x.path })) });
    }
    if (req.method === "GET" && url.pathname === "/api/file") {
      const abs = safePath(url.searchParams.get("path") || "");
      if (!fs.existsSync(abs) || !fs.statSync(abs).isFile()) return json(res, 404, { error: "File not found" });
      const stat = fs.statSync(abs);
      if (stat.size > 500_000) return json(res, 413, { error: "File too large to preview (limit 500 KB)" });
      const content = fs.readFileSync(abs, "utf8");
      return json(res, 200, { path: relativeName(abs), content });
    }
    if (req.method === "POST" && url.pathname === "/api/file") {
      const body = await readBody(req);
      if (typeof body.path !== "string" || typeof body.content !== "string") return json(res, 400, { error: "Expected path and content strings" });
      const abs = safePath(body.path);
      if (!fs.existsSync(abs) || !fs.statSync(abs).isFile()) return json(res, 400, { error: "Only existing files can be saved in this MVP" });
      if (body.content.length > 500_000) return json(res, 413, { error: "File exceeds 500 KB limit" });
      fs.writeFileSync(abs, body.content, "utf8");
      event({ type: "file.changed", path: relativeName(abs), text: "File saved from editor" });
      return json(res, 200, { ok: true, path: relativeName(abs) });
    }
    if (req.method === "GET" && url.pathname === "/api/system-prompt") {
      const config = promptManager.get();
      return json(res, 200, { corePrompt: config.corePrompt, customInstructions: config.customInstructions, version: config.version, customPath: config.customPath, maxCustomCharacters: 30000 });
    }
    if (req.method === "PUT" && url.pathname === "/api/system-prompt") {
      const body = await readBody(req);
      if (typeof body.customInstructions !== "string") return json(res, 400, { error: "Expected customInstructions string" });
      if (body.customInstructions.length > 30000) return json(res, 413, { error: "Custom instructions must be at most 30,000 characters" });
      const config = promptManager.updateCustomInstructions(body.customInstructions);
      event({ type: "prompt.updated", promptVersion: config.version, text: `TIKI custom instructions updated · ${config.version}` });
      return json(res, 200, { ok: true, corePrompt: config.corePrompt, customInstructions: config.customInstructions, version: config.version, customPath: config.customPath });
    }
    if (req.method === "POST" && url.pathname === "/api/chat") {
      const body = await readBody(req);
      if (!["opencode", "hermes", "openclaw"].includes(body.agent)) return json(res, 400, { error: "Choose a supported agent" });
      if (typeof body.prompt !== "string" || !body.prompt.trim() || body.prompt.length > 20_000) return json(res, 400, { error: "Prompt must be 1–20,000 characters" });
      const result = await runChat(body.agent, body.prompt.trim());
      return json(res, 200, result);
    }
    if (req.method === "GET" && url.pathname === "/api/subagents") {
      return json(res, 200, { subagents: subagents.list() });
    }
    if (req.method === "POST" && url.pathname === "/api/subagents") {
      const body = await readBody(req);
      const item = subagents.add(body);
      event({ type: "subagent.added", text: `Added sub-agent: ${item.name}`, subagent: item });
      return json(res, 201, { subagent: item, subagents: subagents.list() });
    }
    if (req.method === "DELETE" && url.pathname.startsWith("/api/subagents/")) {
      const id = decodeURIComponent(url.pathname.split("/").pop());
      const items = subagents.remove(id);
      event({ type: "subagent.removed", text: `Removed sub-agent ${id}` });
      return json(res, 200, { subagents: items });
    }
    if (req.method === "PATCH" && url.pathname.startsWith("/api/subagents/")) {
      const id = decodeURIComponent(url.pathname.split("/").pop());
      const body = await readBody(req);
      const item = subagents.toggle(id, body.enabled);
      event({ type: "subagent.updated", text: `Updated sub-agent: ${item.name}`, subagent: item });
      return json(res, 200, { subagent: item, subagents: subagents.list() });
    }
    if (req.method === "GET" && url.pathname === "/api/tools/catalog") {
      return json(res, 200, { categories: [
        { id: "weather", label: "Weather APIs", status: "extension-point", description: "Public weather and forecast providers" },
        { id: "markets", label: "Market data", status: "extension-point", description: "Stocks, FX, crypto, and public financial datasets" },
        { id: "scraping", label: "Web extraction", status: "extension-point", description: "Provider-allowlisted, rate-limited extraction that respects site terms" },
        { id: "public-data", label: "Public APIs", status: "extension-point", description: "Other non-AI HTTP APIs and public datasets" }
      ] });
    }
    if (req.method === "POST" && url.pathname === "/api/command") {
      const body = await readBody(req);
      const allowed = {
        "git status": ["git", ["status", "--short"]],
        "git diff stat": ["git", ["diff", "--stat"]],
        "list files": [process.platform === "win32" ? "cmd" : "ls", process.platform === "win32" ? ["/c", "dir"] : ["-la"]],
        "node version": ["node", ["--version"]]
      };
      if (!Object.hasOwn(allowed, body.command)) return json(res, 403, { error: "Command not in the MVP allowlist" });
      const [bin, args] = allowed[body.command];
      event({ type: "command.started", command: body.command, text: `Running approved command: ${body.command}` });
      const childEnv = { PATH: process.env.PATH || "", HOME: process.env.HOME || "" };
      if (process.platform === "win32") childEnv.SystemRoot = process.env.SystemRoot || "C:\\Windows";
      const child = spawn(bin, args, { cwd: WORKSPACE, shell: false, windowsHide: true, env: childEnv });
      let output = "";
      child.stdout.on("data", d => { output += d.toString(); });
      child.stderr.on("data", d => { output += d.toString(); });
      const timer = setTimeout(() => child.kill("SIGTERM"), 10_000);
      child.on("close", code => {
        clearTimeout(timer);
        event({ type: "command.completed", command: body.command, success: code === 0, text: `Exit code ${code}` });
        json(res, 200, { command: body.command, code, output: output.slice(0, 20_000) });
      });
      return;
    }
    if (req.method === "GET" && url.pathname === "/api/events") {
      res.writeHead(200, { "content-type": "text/event-stream", "cache-control": "no-cache, no-transform", connection: "keep-alive", "x-accel-buffering": "no" });
      res.write(`data: ${JSON.stringify({ type: "connected", text: "Connected to TIKI event stream", at: new Date().toISOString() })}\n\n`);
      clients.add(res);
      const heartbeat = setInterval(() => res.write(": keepalive\n\n"), 15_000);
      req.on("close", () => { clearInterval(heartbeat); clients.delete(res); });
      return;
    }
    if (req.method === "GET") {
      const requested = url.pathname === "/" ? "index.html" : decodeURIComponent(url.pathname.slice(1));
      const abs = path.resolve(PUBLIC, requested);
      if (abs !== PUBLIC && !abs.startsWith(PUBLIC + path.sep)) return json(res, 403, { error: "Forbidden" });
      if (!fs.existsSync(abs) || !fs.statSync(abs).isFile()) return json(res, 404, { error: "Not found" });
      const type = abs.endsWith(".html") ? "text/html; charset=utf-8" : abs.endsWith(".css") ? "text/css; charset=utf-8" : abs.endsWith(".js") ? "text/javascript; charset=utf-8" : "application/octet-stream";
      res.writeHead(200, { "content-type": type, "x-content-type-options": "nosniff", "referrer-policy": "no-referrer", "content-security-policy": "default-src 'self'; connect-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; img-src 'self' data:" });
      return fs.createReadStream(abs).pipe(res);
    }
    return json(res, 404, { error: "Not found" });
  } catch (error) {
    if (!res.headersSent) json(res, 500, { error: error.message || "Internal server error" });
    else res.end();
  }
});
server.listen(PORT, HOST, () => {
  console.log("\n  TIKI Universal IDE · MVP");
  console.log(`  Local URL : http://${HOST}:${PORT}`);
  console.log(`  Workspace : ${WORKSPACE}`);
  console.log(`  Runtime   : ${process.version} · ${process.platform}/${process.arch}`);
  console.log("  Security  : loopback bind by default; workspace path guard enabled");
  console.log("  Stop with : Ctrl+C\n");
});
