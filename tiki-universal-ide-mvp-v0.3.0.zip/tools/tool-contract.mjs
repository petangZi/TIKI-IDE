/**
 * Contract for non-AI API/data tools.
 * `execute` must validate input, use an explicit provider allowlist, enforce timeouts,
 * and return normalized data. Do not turn this into an arbitrary URL-fetch proxy.
 */
export const toolContract = {
  id: "example-public-data",
  category: "public-api",
  description: "Example non-AI public-data connector",
  inputSchema: { type: "object", properties: {}, additionalProperties: false },
  async execute(_input, _context) {
    throw new Error("Implement a provider-specific connector with URL allowlisting and timeouts");
  }
};
