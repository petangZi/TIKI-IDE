# TIKI Tools (non-AI integrations)

This folder is for ordinary API integrations and data connectors—not AI model APIs:
- weather and forecast APIs
- market/finance data APIs
- public datasets
- user-authorized web scraping and page extraction
- internal service APIs

Design rules:
1. Keep each connector in its own module.
2. Use explicit provider URLs and documented APIs where available.
3. Never accept arbitrary URLs from browser requests; validate domains to reduce SSRF risk.
4. Respect provider terms, robots directives, rate limits, copyright, and privacy requirements.
5. Store API keys server-side in environment variables; never send secrets to the browser.
6. Normalize responses into small JSON objects and set timeouts/response size limits.

The included examples are intentionally demo-only and do not fetch live data.
