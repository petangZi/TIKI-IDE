const $ = (id) => document.getElementById(id);
let selectedAgent = "opencode";
let activeFilePath = null;
let toastTimer;
const glyphs = { opencode: "⌘", hermes: "✦", openclaw: "⌁" };
const names = { opencode: "OpenCode", hermes: "Hermes", openclaw: "OpenClaw" };

function toast(message) {
  const el = $("toast"); el.textContent = message; el.classList.add("show");
  clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove("show"), 2600);
}
async function api(url, options = {}) {
  const response = await fetch(url, { ...options, headers: { ...(options.body ? { "content-type": "application/json" } : {}), ...(options.headers || {}) } });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
  return data;
}
function addEvent(item) {
  const timeline = $("timeline");
  timeline.querySelector(".empty-state")?.remove();
  const row = document.createElement("div"); row.className = "event-row";
  const icon = document.createElement("div"); icon.className = "event-icon";
  const iconMap = { "run.completed": "✓", "file.changed": "▤", "run.error": "!", "command.completed": "⌁", "assistant.delta": "✦", "tool.progress": "⚙", "command.started": "›", "run.started": "▶", "prompt.attached": "⌘", "prompt.updated": "✎" };
  icon.textContent = iconMap[item.type] || "·";
  if (["run.completed", "command.completed"].includes(item.type) && item.success !== false) icon.classList.add("good");
  if (item.type === "run.error" || item.success === false) icon.classList.add("bad");
  const main = document.createElement("div"); main.className = "event-main";
  const top = document.createElement("div"); top.className = "event-top";
  const title = document.createElement("b");
  const labels = { connected: "Event stream connected", "run.started": `${names[item.agent] || "Agent"} started`, "prompt.attached": "TIKI core prompt attached", "prompt.updated": "TIKI instructions updated", "agent.status": `${names[item.agent] || "Agent"} status`, "assistant.delta": "Agent response", "tool.progress": "Tool activity", "run.completed": "Run completed", "run.error": "Run failed", "file.changed": "File changed", "command.started": "Command started", "command.completed": "Command completed" };
  title.textContent = labels[item.type] || item.type || "Activity";
  const time = document.createElement("span"); time.className = "event-time"; time.textContent = new Date(item.at || Date.now()).toLocaleTimeString();
  top.append(title, time); main.append(top);
  if (item.text) { const text = document.createElement("div"); text.className = "event-text"; text.textContent = item.text; main.append(text); }
  if (item.output) { const code = document.createElement("pre"); code.className = "event-code"; code.textContent = item.output; main.append(code); }
  if (item.path) { const code = document.createElement("pre"); code.className = "event-code"; code.textContent = item.path; main.append(code); }
  row.append(icon, main); timeline.append(row); timeline.scrollTop = timeline.scrollHeight;
  while (timeline.children.length > 100) timeline.firstElementChild.remove();
}
function renderAgents(agents) {
  const root = $("agents"); root.replaceChildren();
  let online = 0;
  for (const agent of agents) {
    if (agent.detected) online++;
    const button = document.createElement("button"); button.className = `agent-card${selectedAgent === agent.id ? " selected" : ""}`; button.type = "button";
    const glyph = document.createElement("span"); glyph.className = "agent-glyph"; glyph.textContent = glyphs[agent.id] || "◇";
    const info = document.createElement("span"); const name = document.createElement("b"); name.textContent = agent.name;
    const detail = document.createElement("small"); detail.textContent = agent.detail;
    info.append(name, detail); const state = document.createElement("span"); state.className = `agent-state${agent.detected ? " online" : ""}`;
    button.append(glyph, info, state); button.title = agent.url;
    button.addEventListener("click", () => {
      selectedAgent = agent.id; $("selectedAgentLabel").textContent = `Agent: ${agent.name}`;
      renderAgents(agents);
    });
    root.append(button);
  }
  $("agentCount").textContent = `${online} online · ${agents.length} adapters`;
}
async function loadRuntime() {
  try {
    const data = await api("/api/runtime");
    $("workspacePath").textContent = data.workspace;
    $("serverStatus").textContent = `Core online · ${data.node}`;
    $("runtimeInfo").replaceChildren();
    const rows = [["Platform", `${data.platform}/${data.arch}`], ["Node.js", data.node], ["Git", data.commands.git ? "Detected" : "Not found"], ["OpenCode CLI", data.commands.opencode ? "Detected" : "Not found"], ["Hermes CLI", data.commands.hermes ? "Detected" : "Not found"], ["OpenClaw CLI", data.commands.openclaw ? "Detected" : "Not found"]];
    for (const [label, value] of rows) {
      const row = document.createElement("div"); row.className = "runtime-item";
      const span = document.createElement("span"); span.textContent = label;
      const b = document.createElement("b"); b.textContent = value; if (["Not found"].includes(value)) b.className = "offline";
      row.append(span, b); $("runtimeInfo").append(row);
    }
    renderAgents(data.agents);
  } catch (e) { $("serverStatus").textContent = "Core connection error"; toast(e.message); }
}
async function loadTree() {
  try {
    const data = await api("/api/tree");
    const root = $("fileTree"); root.replaceChildren();
    for (const item of data.entries) {
      const depth = item.path.split("/").length - 1;
      const button = document.createElement("button"); button.className = `tree-item${activeFilePath === item.path ? " active" : ""}`;
      button.style.paddingLeft = `${8 + Math.min(depth, 5) * 12}px`; button.title = item.path;
      const glyph = document.createElement("span"); glyph.className = "tree-icon"; glyph.textContent = item.type === "dir" ? "▸" : "·";
      const label = document.createElement("span"); label.className = "tree-name"; label.textContent = item.name;
      button.append(glyph, label);
      if (item.type === "file") button.addEventListener("click", () => openFile(item.path));
      else button.addEventListener("click", () => toast("Folder is listed; nested browsing is limited in this MVP."));
      root.append(button);
    }
    if (!data.entries.length) root.textContent = "Workspace is empty.";
  } catch (e) { $("fileTree").textContent = e.message; }
}
async function openFile(filePath) {
  try {
    const data = await api(`/api/file?path=${encodeURIComponent(filePath)}`);
    activeFilePath = data.path; $("activeFile").textContent = data.path; $("editorFile").textContent = data.path;
    $("fileEditor").value = data.content; $("editorEmpty").hidden = true; $("editorWrap").hidden = false;
    $("fileBadge").textContent = "EDITABLE"; await loadTree();
  } catch (e) { toast(e.message); }
}
async function saveFile() {
  if (!activeFilePath) return;
  try {
    await api("/api/file", { method: "POST", body: JSON.stringify({ path: activeFilePath, content: $("fileEditor").value }) });
    toast(`Saved ${activeFilePath}`); addEvent({ type: "file.changed", path: activeFilePath, text: "Saved from quick file editor." }); await loadTree();
  } catch (e) { toast(e.message); }
}
async function sendPrompt() {
  const prompt = $("prompt").value.trim(); if (!prompt) return toast("Write a task first.");
  $("sendPrompt").disabled = true; $("sendPrompt").textContent = "Running…";
  addEvent({ type: "run.started", agent: selectedAgent, text: "Request submitted from TIKI Workspace." });
  try {
    const data = await api("/api/chat", { method: "POST", body: JSON.stringify({ agent: selectedAgent, prompt }) });
    if (data.answer) addEvent({ type: "assistant.delta", text: data.answer, at: new Date().toISOString() });
    $("prompt").value = "";
  } catch (e) { addEvent({ type: "run.error", agent: selectedAgent, text: e.message }); toast(e.message); }
  finally { $("sendPrompt").disabled = false; $("sendPrompt").innerHTML = 'Run agent <span>↗</span>'; }
}

async function loadSystemPrompt() {
  try {
    const data = await api("/api/system-prompt");
    $("corePromptPreview").textContent = data.corePrompt;
    $("customInstructions").value = data.customInstructions || "";
    $("promptVersion").textContent = `Effective prompt · ${data.version}`;
    $("promptChars").textContent = `${$("customInstructions").value.length.toLocaleString()} / 30,000`;
  } catch (e) { $("corePromptPreview").textContent = `Could not load core prompt: ${e.message}`; }
}
async function saveSystemPrompt() {
  const customInstructions = $("customInstructions").value;
  try {
    const data = await api("/api/system-prompt", { method: "PUT", body: JSON.stringify({ customInstructions }) });
    $("promptVersion").textContent = `Effective prompt · ${data.version}`;
    toast("TIKI custom instructions saved.");
  } catch (e) { toast(e.message); }
}
$("customInstructions").addEventListener("input", () => { $("promptChars").textContent = `${$("customInstructions").value.length.toLocaleString()} / 30,000`; });
$("savePrompt").addEventListener("click", saveSystemPrompt);

async function loadSubagents() {
  try {
    const data = await api("/api/subagents");
    const root = $("subagents"); root.replaceChildren();
    if (!data.subagents.length) { const empty = document.createElement("div"); empty.className = "muted small"; empty.textContent = "No sub-agents configured yet."; root.append(empty); return; }
    for (const agent of data.subagents) {
      const row = document.createElement("div"); row.className = "subagent-item";
      const info = document.createElement("div"); info.className = "subagent-info";
      const title = document.createElement("b"); title.textContent = agent.name;
      const meta = document.createElement("small"); meta.textContent = `${names[agent.agent] || agent.agent} · ${agent.role} · ${agent.enabled ? "enabled" : "disabled"}`;
      info.append(title, meta);
      const toggle = document.createElement("button"); toggle.className = "mini-action"; toggle.textContent = agent.enabled ? "Disable" : "Enable";
      toggle.addEventListener("click", async () => { try { await api(`/api/subagents/${encodeURIComponent(agent.id)}`, { method: "PATCH", body: JSON.stringify({ enabled: !agent.enabled }) }); await loadSubagents(); } catch(e) { toast(e.message); } });
      const remove = document.createElement("button"); remove.className = "mini-action remove"; remove.textContent = "Remove";
      remove.addEventListener("click", async () => { if (!confirm(`Remove sub-agent "${agent.name}"?`)) return; try { await api(`/api/subagents/${encodeURIComponent(agent.id)}`, { method: "DELETE" }); await loadSubagents(); toast("Sub-agent removed."); } catch(e) { toast(e.message); } });
      row.append(info, toggle, remove); root.append(row);
    }
  } catch (e) { $("subagents").textContent = e.message; }
}
async function addSubagent() {
  const name = $("subagentName").value.trim();
  if (!name) return toast("Give the sub-agent a name first.");
  try {
    await api("/api/subagents", { method: "POST", body: JSON.stringify({ name, agent: $("subagentEngine").value, role: $("subagentRole").value.trim() || "general" }) });
    $("subagentName").value = ""; $("subagentRole").value = ""; await loadSubagents(); toast("Sub-agent added.");
  } catch (e) { toast(e.message); }
}
async function loadToolCatalog() {
  try {
    const data = await api("/api/tools/catalog");
    const root = $("toolCatalog"); root.replaceChildren();
    const glyph = { weather: "☼", markets: "↗", scraping: "⌕", "public-data": "◇" };
    for (const tool of data.categories) {
      const row = document.createElement("div"); row.className = "catalog-item";
      const icon = document.createElement("span"); icon.className = "catalog-glyph"; icon.textContent = glyph[tool.id] || "◇";
      const info = document.createElement("div"); info.className = "catalog-info";
      const title = document.createElement("b"); title.textContent = tool.label;
      const desc = document.createElement("small"); desc.textContent = tool.description;
      info.append(title, desc);
      const status = document.createElement("span"); status.className = "catalog-status"; status.textContent = "EXTENSION";
      row.append(icon, info, status); root.append(row);
    }
  } catch (e) { $("toolCatalog").textContent = e.message; }
}

async function runCommand(command) {
  const ok = window.confirm(`Run this allowlisted command in the selected workspace?\n\n${command}\n\nThis MVP does not accept arbitrary shell commands.`);
  if (!ok) return;
  try {
    const data = await api("/api/command", { method: "POST", body: JSON.stringify({ command }) });
    addEvent({ type: "command.completed", command, success: data.code === 0, text: `Exit code ${data.code}`, output: data.output || "(no output)" });
  } catch (e) { toast(e.message); }
}
$("sendPrompt").addEventListener("click", sendPrompt);
$("addSubagent").addEventListener("click", addSubagent);
$("prompt").addEventListener("keydown", e => { if ((e.ctrlKey || e.metaKey) && e.key === "Enter") sendPrompt(); });
$("saveFile").addEventListener("click", saveFile);
$("refreshFiles").addEventListener("click", loadTree);
$("refreshRuntime").addEventListener("click", loadRuntime);
$("clearTimeline").addEventListener("click", () => { $("timeline").replaceChildren(); addEvent({ type: "connected", text: "Timeline cleared." }); });
document.querySelectorAll("[data-command]").forEach(button => button.addEventListener("click", () => runCommand(button.dataset.command)));
const stream = new EventSource("/api/events");
stream.onmessage = e => { try { addEvent(JSON.parse(e.data)); } catch {} };
stream.onerror = () => { $("serverStatus").textContent = "Reconnecting event stream…"; };
loadRuntime(); loadTree(); loadSystemPrompt(); loadSubagents(); loadToolCatalog();
