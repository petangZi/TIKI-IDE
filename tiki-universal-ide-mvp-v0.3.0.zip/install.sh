#!/usr/bin/env sh
set -eu
echo "TIKI Universal IDE bootstrap"
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js 20+ was not found."
  echo "Install Node.js using the supported method for your OS, then run ./launchers/tiki-ide."
  exit 1
fi
node -e 'const n=+process.versions.node.split(".")[0]; if(n<20){console.error("Node.js 20+ required");process.exit(1)}'
chmod +x launchers/tiki-ide
echo "Bootstrap check passed. No npm dependencies are required."
echo "Run from the project directory you want to open:"
echo "  ./launchers/tiki-ide"
