$ErrorActionPreference = "Stop"
$Root = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  Write-Error "TIKI IDE requires Node.js 20 or newer."
}
$Major = [int]((node -p "Number(process.versions.node.split('.')[0])").Trim())
if ($Major -lt 20) { Write-Error "Node.js 20+ required." }
if (-not $env:TIKI_WORKSPACE) { $env:TIKI_WORKSPACE = (Get-Location).Path }
node (Join-Path $Root "server.mjs")
