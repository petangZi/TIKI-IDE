/**
 * Illustrative normalized contract for future adapter plugins.
 * The current MVP's connectors are implemented in server.mjs.
 */
export const adapterContract = {
  id: "example-agent",
  label: "Example Agent",
  capabilities: {
    chat: true,
    streaming: false,
    toolEvents: false,
    fileDiffs: false,
    cancel: false
  },
  async detect() {
    return { available: false, reason: "Implement a real health check" };
  },
  async *run({ prompt, workspace, sessionId }) {
    // Yield only events grounded in real adapter observations.
    yield { type: "agent.status", sessionId, text: "Adapter example is not connected." };
    yield { type: "run.error", sessionId, text: "Not implemented." };
  }
};
