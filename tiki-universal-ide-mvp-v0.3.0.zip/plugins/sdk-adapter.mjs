/**
 * SDK adapter contract for third-party agent libraries.
 * SDKs are loaded by a trusted local plugin package, not uploaded from the browser.
 */
export const sdkAdapterContract = {
  id: "example-sdk",
  label: "Example SDK Agent",
  capabilities: ["chat"],
  async detect() { return { available: false, reason: "Implement SDK-specific detection" }; },
  async run({ prompt, workspace, emit }) {
    emit({ type: "agent.status", text: "SDK adapter example is not configured" });
    throw new Error("SDK adapter not implemented");
  },
  async cancel() { return { supported: false }; }
};
