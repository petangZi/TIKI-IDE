# Adapter plugins

TIKI's first MVP includes built-in connectors for:
- OpenCode native HTTP API
- Hermes OpenAI-compatible Chat Completions endpoint
- OpenClaw OpenAI-compatible Chat Completions endpoint

Future plugins should implement a normalized event contract and keep credentials server-side. See `adapter-contract.mjs`.

Recommended plugin lifecycle:
1. `detect()` checks a configured endpoint or executable.
2. `health()` returns availability without exposing credentials.
3. `send()` starts a run and yields normalized events.
4. `cancel()` is optional and must be supported only when the underlying engine offers cancellation.
5. Declare capabilities (`chat`, `streaming`, `toolEvents`, `diffs`, `cancel`, `workspaceTools`) honestly.

Never assume every agent exposes the same native tool events. Do not fabricate tool calls or file diffs when the adapter cannot observe them.
