import fs from "node:fs";
import path from "node:path";

export function createSubagentStore(workspace) {
  const configDir = path.join(workspace, ".tiki");
  const configFile = path.join(configDir, "subagents.json");
  function read() {
    try {
      const value = JSON.parse(fs.readFileSync(configFile, "utf8"));
      return Array.isArray(value.subagents) ? value.subagents : [];
    } catch { return []; }
  }
  function write(subagents) {
    fs.mkdirSync(configDir, { recursive: true });
    fs.writeFileSync(configFile, JSON.stringify({ version: 1, subagents }, null, 2), { mode: 0o600 });
  }
  return {
    list: read,
    add(input) {
      if (!input || typeof input.name !== "string" || !input.name.trim()) throw new Error("Sub-agent name is required");
      if (!["opencode", "hermes", "openclaw"].includes(input.agent)) throw new Error("Unsupported sub-agent engine");
      const items = read();
      const item = { id: crypto.randomUUID(), name: input.name.trim().slice(0, 80), agent: input.agent, role: String(input.role || "general").slice(0, 80), enabled: input.enabled !== false };
      items.push(item); write(items); return item;
    },
    remove(id) {
      const items = read();
      const next = items.filter(item => item.id !== id);
      if (next.length === items.length) throw new Error("Sub-agent not found");
      write(next); return next;
    },
    toggle(id, enabled) {
      const items = read();
      const found = items.find(item => item.id === id);
      if (!found) throw new Error("Sub-agent not found");
      found.enabled = !!enabled; write(items); return found;
    }
  };
}
