/**
 * MCP adapter boundary.
 * This module documents the transport seam; it does not claim to implement the
 * full MCP protocol. Add a tested MCP SDK transport before enabling real servers.
 */
export const mcpAdapter = {
  id: "mcp",
  label: "Model Context Protocol",
  capabilities: ["tools/list", "tools/call", "resources/list", "prompts/list"],
  status: "interface-only",
  async connect({ transport, endpoint }) {
    if (!["stdio", "http", "sse"].includes(transport)) throw new Error("Unsupported MCP transport");
    if (!endpoint) throw new Error("MCP endpoint or command is required");
    return { connected: false, transport, endpoint, note: "Wire a maintained MCP SDK transport here before enabling calls." };
  }
};
